/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class db {
   final static String driver = "org.apache.derby.jdbc.EmbeddedDriver";
   final static String DB_url = "jdbc:derby://localhost:1527/Hospital";
   final static String USER = "Arefin";
   final static String PASS = "Arefin";
   
   
  public static Connection getConnection(){
  try{
   Class.forName(driver);
   Connection conn = DriverManager.getConnection(DB_url,USER,PASS);
   System.out.println("Connected");
   return conn;
  }
  catch(ClassNotFoundException | SQLException e){
      //System.out.println(e);
      JOptionPane.showMessageDialog(null, e);
      return null;
  }
  
  
  
 }
}
